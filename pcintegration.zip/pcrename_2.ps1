﻿$nom = Read-Host("Saisir le nom de PC portable")

Rename-Computer $nom

# Supprimez la tache créé par le 1er script | Delete the task that was created by 1st script

schtasks /delete /tn "PCRename" /f

# Avant de redémarrer, ajoutez la commande pour créer une tache planifiée après l'ouverture de session. | Before Restart, put command to create scheduled task on "Startup" or on "Logon" for "pcjoin.ps1"

schtasks /create /tn "PCJoin" /tr "powershell.exe -ExecutionPolicy Bypass -File C:%HOMEPATH%\Downloads\pcjoin_3.ps1" /rl highest /sc onlogon

Restart-Computer -Force # Besoin de redémarrer pour appliquer les modifications | Need to restart to confirm and apply the changes
