﻿rm C:$env:HOMEPATH\Downloads\pcleave_1.ps1
rm C:$env:HOMEPATH\Downloads\pcrename_2.ps1
rm C:$env:HOMEPATH\Downloads\pcjoin_3.ps1
rm C:$env:HOMEPATH\Downloads\pcrename_SI_1.ps1
rm C:$env:HOMEPATH\Downloads\pcintegration.zip

schtasks /delete /tn "PCDone" /f

rm C:$env:HOMEPATH\Downloads\pcdone_4.ps1