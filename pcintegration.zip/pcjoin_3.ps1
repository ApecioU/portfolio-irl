﻿$liste_domaine = [Ordered]@{ 
"1" = "groupe-pedago.loc"; 
"2" = "groupe-igs.asso.fr"; 
"3" = "apes.lab"
}

Write-Output $liste_domaine

do {
    $domaine = Read-Host `n , "Choissisez le domaine correspondant"

    if ($liste_domaine.Contains($domaine)) {
        Add-Computer -DomainName $liste_domaine[$domaine]
    } else {
        Write-Output `n, "Merci d'entrer un numéro qui fait partie de la liste de domaine seulement."
    }
    } until ($liste_domaine.Contains($domaine))

# Supprimez la tache créé par le 2ème script | Delete the task made by 2nd script

schtasks /delete /tn "PCJoin" /f

# Créez la tache pour supprimer les fichiers ps1 et zip utilisés pour le script

schtasks /create /tn "PCDone" /tr "powershell.exe -ExecutionPolicy Bypass -File C:%HOMEPATH%\Downloads\pcdone_4.ps1" /rl highest /sc onlogon

# Besoin de redémarrer pour appliquer les modifications | Need to restart to confirm and apply the changes

do {
    $deplacer = Read-Host `n, "Avez-vous déplacé le PC dans le bon OU ?" `n, "Entrez 'y' pour Oui et 'n' pour Non"
    
    if ($deplacer -eq 'y'){
        Restart-Computer -Force 
    }
    
    elseif ($deplacer -eq 'n'){
        Write-Host 
    }
    
    else{
    Write-Output `n, "Merci d'entrer 'y' ou 'n' seulement."
    }
    } until ($deplacer -eq 'y')

# Exemple d'un nom de PC portable entreprise : P12APESCASIO10

# Au lieu de do et until, on peut aussi utiliser une boucle "While":

#While(-not($input -eq 'yes') -and -not($input -eq 'no')){
#$input = read-host "Enter Yes or No"
#if ($input -eq 'yes'){
#echo Restart-Computer -Force
#}elseif ($input -eq 'no'){
#Write-Output "You typed 'no'."
#}else{
#Write-Output "Please only type in 'yes' or 'no'."
#}}
#Write-Output "Done!"

