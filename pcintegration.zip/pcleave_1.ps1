# Apr�s le ghost / masterisation, le PC va se retrouver dans un domaine, je commence donc le script en sortant du domaine. | After the ghost / masterisation, the PC will be in a domain, so I start the script by removing it.

Remove-Computer -UnjoinDomainCredential "" -WorkgroupName "DomainLeave" -Force

# Avant de red�marrer, ajoutez la commande pour cr�er une tache planifi�e apr�s l'ouverture de session. | Before Restart, put command to create scheduled task on "Startup" or on "Logon" for "pcrename.ps1"

schtasks /create /tn "PCRename" /tr "powershell.exe -ExecutionPolicy Bypass -File C:$env:HOMEPATH\Downloads\pcrename_2.ps1" /rl highest /sc onlogon

# Besoin de red�marrer pour appliquer les modifications | Need to restart to confirm and apply the changes

Restart-Computer -Force


# les domaines de l'entreprise: groupe-igs.asso.fr , groupe-pedago.loc
# exemple d'un nom de PC portable entreprise : P12APESCASIO10